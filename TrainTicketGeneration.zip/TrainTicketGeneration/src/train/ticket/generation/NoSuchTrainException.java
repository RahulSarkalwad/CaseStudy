package train.ticket.generation;

public class NoSuchTrainException extends Exception {

	@Override
	public String getMessage() {
		return "There is no train of this train number";
	}
	
}
